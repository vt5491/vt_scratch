# setup

require "mongo"
include Mongo

db = MongoClient.new("localhost", 27017, w: 1).db("mongo_test_development")
dbpc = db.collection("dbpc")
jc = db.collection("jeopardy")

db.collection(:tmp_decorated_jeo).drop()
    
jc.find().skip(0).limit(0).each do |r|
  answer = r['answer'].to_s.gsub(/[ ]/, '_')

  wiki = dbpc.find_one({ :res1 => answer, :$or => [ { :prop => /born/i }, { :prop => /dateOfBirth/i}, { :prop => /birthdate/i} ] } )      

  if wiki
    # clean up date
    /(\d{4}-\d{2}-\d{2})/ =~ wiki['res2']

    dob = $1
    
    # add a dob
    r['dob'] = dob
  end

  db.collection(:tmp_decorated_jeo).insert(r)
end

