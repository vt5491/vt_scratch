print "hello\n"

# setup

require "mongo"
include Mongo

# turn the parse cell into a sub, with the filename paramterized.  We want to call again
# going against the AC/DC extract file
#
# Note: skip is applied before limit.  limit then applies after any
# skipped records have been skipped.
#
# note: if you specify coll, then you don't have to worry about
# gettint the full result passed back to you, as we don't populate
# 'tbl' if 'coll' is passed.
# coll and to_tsv should be mutually exclusive and never specified together
def parse_nt_file(params)
  fn     = params[:fn] || abort("please specify a fn parm")
  coll   = params[:coll]
  limit  = params[:limit]
  skip   = params[:skip]
  print  = params[:print]
  to_tsv = params[:to_tsv]
  tsv_fn = params[:tsv_fn]
  tsv_header_line = params[:tsv_header_line]
  
  skip_cnt  = 0
  limit_cnt = 0
  tbl = []
  
  if (coll && to_tsv)
    p "Error: specify just one of either coll or to_tsv, never both"
    return
  end

  if (to_tsv == 1 && tsv_fn)
    tsv_out = File.open(tsv_fn, 'w') 
    p "filename=#{tsv_out.path}"
    # print the headerline
    # remove any added newlines 
    tsv_header_line.chomp!()
    tsv_out.write("#{tsv_header_line}\n")
  end 

  File.open(fn).each do |line|
    skip_cnt = skip_cnt + 1

    if (skip && skip_cnt <= skip)
      # skip this rec
      next
    end

    %r{<http://dbpedia.org/resource/([^>]*)>[\s]*<http://dbpedia.org/property/([^>]*)>[\s]*(.*)} =~ line

    res1 = $1
    prop = $2
    # extract stuff from $3 if it's in a know http form
    res2 = $3

    # we're just breaking the regex into two parts, so the first isn't so compicated.
    # Here we're just checking if the second resource is a "resource" type.  If yes,
    # extract the "meat" and drop the fluff
    if (%r{<http://dbpedia.org/resource/([^>]*)}.match(res2))
      res2 = $1
    end

    # if it's a number type, drop the fluff
    if (%r{([^>]*)<http://www.w3.org/2001/XMLSchema#int>}.match(res2))
      res2 = $1
    end

    if (coll)
      # insert to collection
      begin
        coll.insert({ "res1" => res1, "prop" => prop, "res2" => res2}, :continue_on_error => true)
      rescue
        #p "dup error, carrying on"
      end
    elsif (to_tsv == 1 && tsv_fn)
      #File.open(yourfile, 'w') { |file| file.write("your text") }
      tsv_out.write("#{res1}\t#{prop}\t#{res2}\n")
    else
      # print out
      #p "#{res1},#{prop},#{res2}"
      tbl.push [res1, prop, res2] 
    end
    
    limit_cnt = limit_cnt + 1

    break if (limit && limit > 0 && limit_cnt >= limit)
  end

  # print out the tbl, if any
  if (!print || print == 0)
    return tbl
  else
    IRuby.display IRuby.table(tbl)
  end
end

db = MongoClient.new("localhost", 27017, w: 1).db("mongo_test_development")
#jmc = db.collection("jeo_mini")
#jmc_base = db.collection("jeo_mini_base")
#jc = db.collection("jeopardy")
dbpc = db.collection("dbpc")

# this is used to read the whole thing
#a = parse_nt_file({:fn => '/mnt/data/input/infobox_properties_en.nt', :coll => dbpc, :limit => 0 , :print => 0})

## this is used to skip
#result = parse_nt_file({:fn => '/mnt/data/infobox_properties_en.nt', 
##    :coll => dbpc, 
#    :skip  => 8638464, 
#    :limit => 5 , 
#    :print => 0
#})

# this is used to skip and insert
#result = parse_nt_file({
#    :fn => '/mnt/data/infobox_properties_en.nt', 
#    :coll => dbpc, 
#    #:skip  => 8638469, 
#    :skip  => 22184447, 
#    :limit => 0 , 
#    :print => 0
#})

result = parse_nt_file({
    :fn => '/mnt/data/infobox_properties_en.nt', 
    #:coll => dbpc, 
    #:skip  => 8638469, 
    :skip  => 24108681, 
    #:skip  => 3, 
    :limit => 0, 
    :to_tsv => 1,
    :tsv_fn => '/home/ubuntu/vtstuff/tmp/info_props_mass_insert.tsv',
    :tsv_header_line => "res1\tprop\tres2",
    :print => 0
})
